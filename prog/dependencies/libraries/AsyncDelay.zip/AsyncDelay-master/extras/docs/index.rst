.. toctree::
   :maxdepth: 2

.. include:: ../../README.rst
   :end-before: Documentation

Class Documentation
-------------------
.. doxygenclass:: AsyncDelay
   :project: AsyncDelay
   :members:

----

This documentation was built using ArduinoDocs_.

.. _ArduinoDocs: http://arduinodocs.readthedocs.org
